# README

Copyright 2024 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.

## IB REST API Examples

Prior to running the examples, please make sure that you obtain your
`clientId` and `clientSecret` credentials provided by Bloomberg. These credentials
will be used to authenticate with the Bloomberg Cloud Infrastructure.

# Quick Start

1. Navigate to the `sample_code_node` directory.

2. Run `npm i` to install the dependencies from `package.json`

3. You will need to provide `jwtCreator.js` with the correct values for `clientId` and `clientSecret` (as given to you by Bloomberg). You will also need to set the `host` variable to the URL of the API. Here are two options:

   - Use an `.env` file to set these values. Copy `/env/.env` to the project directory (same directory as jwtCreator). Populate the values for CLIENT_ID, CLIENT_SECRET, and HOST. These values will handled by `.dotenv`. Be sure not to check in the `.env` file to your source control, as you should treat `clientId` and `clientSecret` as confidential.
   - Alternatively, you can hard-code the values in code by setting the `clientId`, `clientSecret` and `host` values manually. This is not recommended as you may inadvertantly check this into your source control.

4. Run an example

	```
	> node exampleDocumentation.js
	```

<hr>

### exampleDocumentation.js

This example returns full json schema for the requests.

### exampleChatInitiation.js

This example illustrates how to send chat initiation request. The uuid/roomId information provided need to be replaced by intended values (you can hard code these values; or put in the `.env` file).
