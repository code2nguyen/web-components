// Sample code to get a list of available streams

const { get } = require('./common.js');

get("/ib/v1/streams");


