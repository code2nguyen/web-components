# Bloomberg Web Services APIs

### Service mode workflow

- [Bloomberg Web Services APIs](#bloomberg-web-services-apis)
    - [Service mode workflow](#service-mode-workflow)
    - [Introduction](#introduction)
    - [Credentials](#credentials)
  - [JWT](#jwt)

### Introduction

All Bloomberg Web Services APIs require JSON Web Tokens (JWT) with every API call to access API endpoints.
This documentation walks through samples from the Python SDK to describe the process of creating & using
JWT.

### Credentials

Credentials required to sign the JWT will be provided by Bloomberg upon request.
The credentials are delivered in a text file containing JSON data for several key:value pairs.
Credentials may expire at a pre-determined point in the future. When they do, the JSON data will
include an "expiration" key indicating that last date the credentials will be valid.

Example credential file:

```json
{
    "clientId": "54321e2f4c2a4602abf0240747694e3a",
    "clientSecret": "ee789e8b98e44b03a5f4c907312e922e4046ab1225ec45b78ab1bb21f528d669",
    "expiration" : "2017-10-19 10:23:54+02"
}
```

| key           |  description
| ------------  | ----------------
| client_id     | key ID passed in as iss value per request
| client_secret | key secret (associated w/ client_id) used to sign JWT. Provided in hex format.
| expiration    | credential expiration time.

## JWT

The JWT must be signed using the credential provided by Bloomberg.
Please refer to JWT documentation present inside the documentation folder for
more information.

From the python SDK, JWT can be constructed as demonstrated in the `common.py` file
inside the samples folder.

----
Copyright 2017 Bloomberg Finance L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.
