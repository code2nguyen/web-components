const CryptoJS = require("crypto-js");
const uuid = require("uuid");
require('dotenv').config();

/*
You will need to provide the correct values for `clientId` and `clientSecret` and `host` (provided by Bloomberg):
Recommended: Use an `.env` file to set these values.

  - Copy `/env/.env` to the project directory (same directory as jwtCreator).
    Populate the values for CLIENT_ID, CLIENT_SECRET, and HOST.
    - These values will handled by `dotenv`. Be sure not to check in the `.env` file to your source control,
      as you should treat `clientId` and `clientSecret` as confidential.
  - Alternatively, you can hard-code the values in code by setting the `clientId`, `clientSecret` and `host` values manually.
*/

const clientId = process.env.CLIENT_ID || 'e0000000000000000000000000000000';
const clientSecret = process.env.CLIENT_SECRET || 'e0000000000000000000000000000000';
// host url provided by Bloomberg
const host =  process.env.HOST || 'host-url';

// ------------------------------------------------------------
// CONSTRUCT JTW TOKEN / PAYLOAD
// ------------------------------------------------------------

function getJwtPayload(clientId, path, host, method) {
    const requestId = uuid.v4();
    const iat = Math.floor(Date.now() / 1000);
    return {
        'exp': iat + 3600,
        'iat': iat,
        'nbf': iat,
        'iss': clientId,
        'method': method,
        'path': path,
        'host': host,
        'request_id': requestId,
        'region': 'default' // 'default' is the only allowed value for region
    };
}

function generateAutoHeader(jwtPayload, clientSecret) {
    const clientSecretBlob = CryptoJS.enc.Hex.parse(clientSecret);
    const base64url = function (string) {
        const base64 = CryptoJS.enc.Base64.stringify(string);
        return base64.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    };

    const base64urlObject = function (object) {
        return base64url(CryptoJS.enc.Utf8.parse(JSON.stringify(object)));
    };

    const header = {
        alg: "HS256",
        typ: "JWT",
    };

    const unsignedToken =
        base64urlObject(header) + "." + base64urlObject(jwtPayload);
    const signature = base64url(
        CryptoJS.HmacSHA256(unsignedToken, clientSecretBlob)
    );
    const jwt = unsignedToken + "." + signature;

    return jwt;
}

function getUrlWithJwt(path, method) {
    const jwtPayload = getJwtPayload(clientId, path, host, method);
    const jwt = generateAutoHeader(jwtPayload, clientSecret);
    return host + path + "?jwt=" + jwt;
}

module.exports = getUrlWithJwt;
