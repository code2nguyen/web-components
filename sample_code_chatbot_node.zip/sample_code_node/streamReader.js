const getUrlWithJwt = require('./jwtCreator.js');
const axios = require('axios');

// Customize according to your retry requirements
const RETRY_ATTEMPTS = 5;

const getDataStream = async(url) => {
    const urlWithJwt = getUrlWithJwt(url, "GET");
    let attempt = 1;
    while(attempt <= RETRY_ATTEMPTS){
        try {
            const response = await axios.get(urlWithJwt, {
                responseType: 'stream'
            });
            attempt = 1;
            return response.data;
        } catch (error) {
            let errorCode = error.response?.status;
            if(errorCode === 503){
                console.log("Server temporarily unavailable (503). Retrying...");
            } else {
                console.error(`Attempt ${attempt} failed: ${error.message}`);
            }
            // Customize according to your retry cadence
            await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
            attempt+=1;
        }
    }
    throw new Error("Failed to connect.");
};

// Data may arrive in incomplete 'chunks'. Complete messages are separated by a newline (\n) character.
// This function buffers chunks as they come in, and processes only complete messages
const processStreamingData = async (data, processEvent) => {
    let buffer = '';
    data.on('data', chunk=> {
        try{
            buffer += chunk.toString();
            const lines = buffer.split('\n');
            for(let i = 0; i < lines.length-1; i++){
                const event = JSON.parse(lines[i]);
                processEvent(event);
            }
            buffer = lines[lines.length - 1];
        } catch (error){
            console.error(`Processing error: ${error}`);
        }
    });
    return new Promise((resolve, reject) => {
        data.on('end', () => {
            console.log('Stream ended');
        });
        data.on('error', error => {
            reject(error);
        });
    });
};

const readStream = async (endpoint, processEvent) => {
    const dataStream = await getDataStream(endpoint);
    await processStreamingData(dataStream, processEvent).catch(error => {
        // If this is a connection reset error, attempt to start a new connection
        if(error.code === 'ECONNRESET'){
            console.error('Connection reset by peer by peer. Reconnecting.');
            readStream();
        } else {
            // Handle other types of errors
            console.error(error);
        }
    });
};

module.exports = readStream;
