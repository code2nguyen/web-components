// Sample code to subscribe to and process events from a stream

const readStream = require('./streamReader.js');
require('dotenv').config();

const streamId = process.env.READ_STREAM_ID || "91111111-9111-4111-b111-d11111111111"; // Replace with valid StreamId
const endpoint = `/ib/v1/streams/${streamId}`;

// Define function that receives an event (json), and
// processes it. In this example we simply print to the console.
const processEvent = (event) => {
    console.log(JSON.stringify(event, null, 2));
};

readStream(endpoint, processEvent);
