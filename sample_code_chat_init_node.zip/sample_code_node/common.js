const axios = require('axios');
const getUrlWithJwt = require('./jwtCreator.js');

function get(path) {
  const url = getUrlWithJwt(path, 'GET');
  axios.get(url)
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
}


async function post(path, json_payload) {
  let uri_with_jwt = getUrlWithJwt(path, "POST");

  try {
    const response = await axios.post(uri_with_jwt, json_payload, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    if (response.status < 200 || response.status >= 300) {
      console.log("Response body: " + response.data);
      throw new Error("Post returned error status: " + response.status + " - " + response.statusText);
    } else {
      console.log("Post success, returned status: " + response.status);
    }
  } catch (error) {
    console.error(error);
  }
}

module.exports = { get, post };
