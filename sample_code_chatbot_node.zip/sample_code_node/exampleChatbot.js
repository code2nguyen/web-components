const { post } = require("./common.js");
require("dotenv").config();

// Fake chatbot UUID, must be replaced with UUID of your chatbot
const chatbotUUID = parseInt(process.env.CHATBOT_UUID) || 11100011;
// Working sample UUID, replace with UUID of user you want to @mention
const atMentionUUID = parseInt(process.env.CHATBOT_AT_MENTION_UUID) || 11098254;
// Ctrl + Shift + R on an IB room to see its ID. ex: "PCHAT-0x100000234567"
const roomId = process.env.CHATBOT_POST_ROOM_ID || "PCHAT-0x100000234567";
// Optional. undefined must be replaced with a string of the postId of an IB message from the same day
const replyToId = process.env.REPLY_TO_ID || undefined;

function createLinkAndMentionPayload() {
    return {
        chatbotId: { uuid: chatbotUUID },
        recipient: { roomId: roomId },
        chatMessage: [
            {
                messageElements: [
                    { contentType: "TEXT", text: "This is a plaintext.\n" },
                    {
                        contentType: "LINK",
                        href: "https://github.com/",
                        title: "This is an http link to visit GitHub",
                    },
                    {
                        contentType: "TEXT",
                        text: "\n Here is an example of an @mention of a user ",
                    },
                    { contentType: "MENTION", user: { uuid: atMentionUUID } },
                    { contentType: "TEXT", text: "\n" },
                ],
            },
        ],
    };
}

function createReplyToPayload() {
    return {
        chatbotId: { uuid: chatbotUUID },
        recipient: { roomId: roomId },
        chatMessage: [
            {
                messageElements: [
                    { contentType: "TEXT", text: "This is a reply." },
                ],
                replyToId: replyToId,
            },
        ],
    };
}

function createTablePayload() {
    return {
        chatbotId: { uuid: chatbotUUID },
        recipient: { roomId: roomId },
        chatMessage: [
            {
                messageElements: [
                    { contentType: "TEXT", text: "This is a table:\n" },
                    {
                        contentType: "TABLE",
                        rows: [
                            {
                                cells: [
                                    {
                                        cell: [
                                            {
                                                text: "Table Example",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "AAA",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "BBB",
                                            },
                                        ],
                                    },
                                ],
                                isHeaderRow: true,
                            },
                            {
                                cells: [
                                    {
                                        cell: [
                                            {
                                                text: "111",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "222",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "rowspan=2",
                                            },
                                        ],
                                        rowspan: 2,
                                    },
                                ],
                            },
                            {
                                cells: [
                                    {
                                        cell: [
                                            {
                                                text: "333",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "444",
                                            },
                                        ],
                                    },
                                ],
                            },
                            {
                                cells: [
                                    {
                                        cell: [
                                            {
                                                text: "555",
                                            },
                                        ],
                                    },
                                    {
                                        cell: [
                                            {
                                                text: "colspan=2",
                                            },
                                        ],
                                        colspan: 2,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
    };
}

function createMarketCommentaryPayload() {
    return {
        chatbotId: { uuid: chatbotUUID },
        recipient: { roomId: roomId },
        chatMessage: [
            {
                messageElements: [
                    {
                        contentType: "TEXT",
                        text: "This is a market commentary:\n",
                    },
                    {
                        contentType: "MARKET COMMENTARY",
                        title: "Out of the Box: Looking Out and Lookout",
                        body: {
                            blocks: [
                                {
                                    type: "Paragraph",
                                    tokens: [
                                        {
                                            type: "Text",
                                            text: "The ",
                                            attributes: { strong: true },
                                        },
                                        {
                                            type: "Text",
                                            text: "markets currently are flummoxed, ",
                                            attributes: { strong: true },
                                        },
                                        {
                                            type: "Text",
                                            text: "in my opinion, and caution is advised. When the height of the ",
                                        },
                                        { type: "Text", text: "Yield Curve" },
                                        { type: "Text", text: " is the " },
                                        { type: "Text", text: "8 month " },
                                        { type: "Text", text: "6 month " },
                                        {
                                            type: "Link",
                                            destination: {
                                                type: "BBLink",
                                                securities: ["IBM US Equity"],
                                                mnemonic: "VRS",
                                                tails: [
                                                    "/G",
                                                    "IB2-APPLICATION",
                                                ],
                                            },
                                            tokens: [
                                                {
                                                    type: "Text",
                                                    text: "Treasury ",
                                                    attributes: { em: true },
                                                },
                                                {
                                                    type: "Text",
                                                    text: "Bill",
                                                    attributes: { em: true },
                                                },
                                            ],
                                        },
                                        {
                                            type: "Text",
                                            text: ", you know that we are nowhere close to normal. ",
                                        },
                                        {
                                            type: "Text",
                                            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec velit purus. Donec lacinia purus vitae risus consequat, id gravida nibh pulvinar. Cras ut velit tincidunt, maximus tortor porta, dapibus urna. In hac habitasse platea dictumst. Donec dapibus diam egestas tincidunt lobortis. Suspendisse ut volutpat est. Mauris pellentesque ante eros, id pulvinar leo mollis in. Ut aliquam neque id risus elementum pellentesque. Vestibulum sit amet mi at purus egestas auctor ut quis nisi. Nulla risus felis, imperdiet at maximus eget, pulvinar eget dui.",
                                        },
                                    ],
                                },
                            ],
                        },
                        metadata: {
                            instruments: [
                                { figi: "BBG000B9XRY4" },
                                { figi: "BBG000N9MNX3" },
                            ],
                        },
                    },
                ],
            },
        ],
    };
}

function createOrderUpdatePayload() {
    return {
        chatbotId: { uuid: chatbotUUID },
        recipient: { roomId: roomId },
        chatMessage: [
            {
                messageElements: [
                    {
                        contentType: "TEXT",
                        text: "This is an Order Update:\n",
                    },
                    {
                        "contentType": "ORDER UPDATE",
                        "body": {
                            "side": "Sell",
                            "size": 17999,
                            "instrument": {
                                "figi": "BBG000BDTBL9"
                            },
                            "orderType": "MKT",
                            "orderStatus": "Rejected",
                            "strategy": "VWAP",
                            "timestamp": 1725354223000,
                            "notes": "Close allocation 1 pct of 21 day avg close volume.",
                            "client": "Bonsai Investment Mgmt",
                            "broker": "Birch Creek Securities",
                            "filledQuantity": 10750,
                            "timeInForce": "FOK",
                            "trader": "Jane Smith",
                            "maxParticipationPercentage": "3%",
                            "benchmark": "S&P 500",
                            "account": "Account Name",
                            "venue": "Venue Name",
                            "totalMarketValue": 44999.9999,
                            "averagePrice": 44999.9999,
                            "targetPrice": 44999.9999
                        }
                    },
                ],
            },
        ],
    };
}

post("/ib/v1/chatbot", createLinkAndMentionPayload());
if (replyToId) {
    post("/ib/v1/chatbot", createReplyToPayload());
}
post("/ib/v1/chatbot", createTablePayload());
post("/ib/v1/chatbot", createMarketCommentaryPayload());
post("/ib/v1/chatbot", createOrderUpdatePayload());
