/**
Sample code to send Idea Drawer request.
Before execution, please check that you have a valid "eventId"

Max of 5 posts is allowed to the same eventId

Other than the success reply you receive,
you should see corresponding action on your Bloomberg screen.
For the example given in this file you will see following text
in idea drawer:

   suggestion string 0
   suggestion string 1
   I want to buy T 3 05/15/45
*/

const { post } = require('./common.js');
require('dotenv').config();

const streamId = process.env.POST_IDEA_STREAM_ID || "91111111-9111-4111-b111-d11111111111";  // Replace with valid StreamId
const eventId = "16547724253190160386"; // Replace with valid EventId

function generateStructuredIdeaPostRequest(eventId) {
    return {
        "@type": "IDEA",
        "eventCorrelationId": eventId,
        "suggestions": [
            {
                "text": "I want to buy",
                "structuredTemplate":
                    [{
                        "@type": "fixed_income_cash",
                        "instrument": {
                            "bbid": "EK336104",
                            "cusip": "01748XAA",
                            "figi": "BBG008N18X67",
                            "ticker": "FCA",
                            "yellow_key": "Corp"
                        },
                        "quote": {
                            "benchmark": "BBG008N18X67",
                            "benchmark_yellow_key": "Corp",
                            "settlement_currency": "EUR",
                            "settlement_date": "September",
                            "underlying_equity": {
                                "price": 29.12,
                                "ticker": "T"
                            },
                            "values": [{
                                "ask_value": 30.11,
                                "bid_value": 30.11,
                                "value_type": "PRICE"
                            }]
                        }
                    }],
                "action": "ORIGINAL_ROOM"
            }
        ]
    };
}

function generateIdeaPostRequest(eventId, numberOfSuggestions = 2) {
    /**
     * Return a idea drawer post request that doesn't support structured payload
     * Arg: number_of_suggestions: number of suggestions in the post request
     */
    const request = {
        '@type': 'IDEA',
        'eventCorrelationId': eventId,
        'suggestions': []
    };

    for (let i = 0; i < numberOfSuggestions; i++) {
        request.suggestions.push({ text: `suggestion string ${i}` });
    }
    return request;
}

function postToStream(eventId, streamId, payloadType) {
    let payload;
    if (payloadType === 0) {
        console.log("sending unstructured idea");
        payload = generateIdeaPostRequest(eventId);
    } else {
        console.log("sending structured idea");
        payload = generateStructuredIdeaPostRequest(eventId);
    }
    const postURL = `/ib/v1/streams/${streamId}`;
    try {
        console.log("posting to " + postURL + "... ");
        post(postURL, payload);
    } catch (e) {
        console.log("caught exception: " + e);
        console.log("URL: " + postURL);
    }
}

function postIdeaToStream() {
    let payloadType = 0; // Text Payload
    postToStream(eventId, streamId, payloadType);
    payloadType = 1; // Structured Payload
    postToStream(eventId, streamId, payloadType);
}

postIdeaToStream();
