# README

Copyright 2024 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.

## IB REST API Examples

Prior to running the examples, please make sure that you obtain your
`clientId` and `clientSecret` credentials provided by Bloomberg. These credentials
will be used to authenticate with the Bloomberg Cloud Infrastructure.

# Quick Start

1. Navigate to the `sample_code_node` directory.

2. Run `npm i` to install the dependencies from `package.json`

3. You will need to provide `jtwCreator.js` with the correct values for `clientId` and `clientSecret` (as given to you by Bloomberg). You will also need to set the `host` variable to the URL of the API. Here are two options:

   - Use an `.env` file to set these values. Copy `/env/.env` to the project directory (same directory as jwtCreator). Populate the values for CLIENT_ID, CLIENT_SECRET, and HOST. These values will handled by `.dotenv`. Be sure not to check in the `.env` file to your source control, as you should treat `clientId` and `clientSecret` as confidential.
   - Alternatively, you can hard-code the values in code by setting the `clientId`, `clientSecret` and `host` values manually. This is not recommended as you may inadvertently check this into your source control.

4. Run an example

    ```sh
    node exampleDocumentation.js
    ```

### exampleReadStream.js

Demonstrates how to listen to the stream data that is posted to a given stream ID.

### examplePostIdea.js

This example sends an Idea Drawer response, but in addition to the ability to send a text formatted suggestions, it also sends suggestions in a structured data ("pill"). To run the service, a valid eventId (that the response respond to) need to be provided. You also have the option of sending the suggestions in the response in text or in structured data.

### examplePostUnsolicitedIdea.js

Similar to "examplePostIdea", except that this version doesn't require an "eventId", but does require supplying a recipient UserId and a destination RoomId.

### exampleStreamlist.js
This example illustrates how to retrieve the list of streams enabled by the firm.
