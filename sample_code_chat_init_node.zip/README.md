# ibapi-client-examples

This repo contains all the documentation relevant to external clients of the IB Connect API.

# About the repository

### authentication_documentation
Contains information about how ibapi does authentication of client endpoints and detailed information about JWT

### sample_code
Sample code exercising various API calls

### API documentation
Refer to our developer console at https://console.bloomberg.com (https://beta.console.bloomberg.com if you only have BETA access) for IB API schema documentation.
