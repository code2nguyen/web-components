/**
Sample code to execute a 'chatbot' scenario.

We listen to events from a stream.

If the chatbot is a member of the room the event message is sent from, and if the
chatbot is 'at mentioned' in the message, then a message will be posted back
to the stream as the chatbot.
*/

const { post } = require('./common.js');
const processStreamEvents = require('./streamReader.js');
require('dotenv').config();

const roomId = process.env.CHATBOT_POST_ROOM_ID || "PCHAT-0x100000222222E"; // Ctrl + Shift + R on an IB room to see its ID.ex: "PCHAT-0x100000234567"
const botUUID = parseInt(process.env.CHATBOT_UUID) || 11100011; // Fake chatbot UUID, must be replaced with UUID of your chatbot
const streamId = process.env.CHATBOT_STREAM_ID || "91111111-9111-4111-b111-d11111111111"; // Replace with valid StreamId
const postPath = "/ib/v1/chatbot";
const streamingPath = `/ib/v1/streams/${streamId}`;

const payload = {
    "chatbotId": {
        "uuid": botUUID,
    },
    "recipient": {
        "roomId": roomId,
    },
    "chatMessage": [{
        "text": "Message posted successfully!"
    }]
};

function chatbotEventProcessor(event) {
    if (
        Object.keys(event).length === 0 ||
        !('roomId' in event) ||
        event.roomId != roomId ||
        !('enrichments' in event)
    ) {
        console.log(event);
        return;
    }

    let isBotAtMentioned = false;
    for (const idx in event.enrichments) {
        let enrichment = event.enrichments[idx];
        if (
            enrichment.hasOwnProperty('@type') &&
            enrichment['@type'] === 'entity_person' &&
            enrichment.instrument.uuid === botUUID
        )
        {
            isBotAtMentioned = true;
            break;
        }
    }

    if (isBotAtMentioned && 'participants' in event) {
        for (const idx in event.participants) {
            const participant = event.participants[idx];
            if (participant.uuid === botUUID) {
                post(postPath, payload);
                break;
            }
        }
    }
};


async function chatbotWorkflow() {
    console.log(`Request endpoint: ${streamingPath}.`);
    console.log("Events from this stream will be received for processing.");

    // The processing function is passed in to 'processStreamEvents',
    // along with the stream url
    await processStreamEvents(
        streamingPath,
        chatbotEventProcessor
    );
}

chatbotWorkflow();
