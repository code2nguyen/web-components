// Postman pre-request script to create JWTs for Bloomberg Web Services.
//
// The following environment variables are expected:
//   clientId: Client ID from Developer Console
//   clientSecret: Client Secret from Developer Console
//
// Security Note: Clients are responsible for managing credentials generated in 
// Developer console. Credentials should be generated specifically for testing
// (do not reuse your production application credentials) with minimal permissions 
// (use BETA instead of PROD where possible) and revoked as soon as they are no 
// longer needed. 
//
// Postman is the property of Postman, Inc and its use is subject to their terms 
// and conditions. Bloomberg does not support and is not responsible in any way for
// Postman usage.
//
// To use the JWT in a request, add a header called "JWT" with the value "{{jwt}}".

const uuid = require('uuid');

const JWT_EXPIRATION = 30; // seconds

const clientId = pm.environment.get('clientId').trim();
const clientSecret = pm.environment.get('clientSecret').trim();

const clientSecretBlob = CryptoJS.enc.Hex.parse(clientSecret);

const base64url = function(string) {
    const base64 = CryptoJS.enc.Base64.stringify(string);
    return base64
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
};

const base64urlObject = function(object) {
    return base64url(CryptoJS.enc.Utf8.parse(JSON.stringify(object)));
};

const host = pm.request.url.host.join('.');
const path = '/' + pm.request.url.path.join('/');
const iat = Math.floor(Date.now() / 1000);
const requestId = uuid.v4();

const header = {
    'alg': 'HS256',
    'typ': 'JWT'
};
const payload = {
    'exp': iat + JWT_EXPIRATION,
    'iat': iat,
    'nbf': iat,
    'iss': clientId,
    'method': request.method,
    'path': path,
    'host': host,
    'request_id': requestId,
    'region': 'ny'
};

const unsignedToken = base64urlObject(header) + "." + base64urlObject(payload);
const signature = base64url(CryptoJS.HmacSHA256(unsignedToken, clientSecretBlob));
const jwt = unsignedToken + '.' + signature;

pm.environment.set('jwt', jwt);
console.log(`Request ID: ${requestId}`);
console.log(`JWT: ${jwt}`);

// ----------------------------------------------------------------------------
// Copyright(C) 2019 Bloomberg Finance L.P.
// All Rights Reserved.
//
// Property of Bloomberg Finance L.P. (BLP)
// This software is made available solely pursuant to the
// terms of a BLP license agreement which governs its use.
// ----------------------------- END-OF-FILE ----------------------------------
