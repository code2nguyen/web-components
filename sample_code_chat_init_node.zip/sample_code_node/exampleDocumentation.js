const { get } = require('./common.js');

get("/ib/v1/documentation.json");
