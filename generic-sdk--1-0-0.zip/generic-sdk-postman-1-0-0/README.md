Postman pre-request script to create JWTs for Bloomberg Web Services.

## Important Notes

Clients are responsible for managing credentials generated in Developer console. Credentials should be generated specifically for testing (do not reuse your production application credentials) with minimal permissions (use BETA instead of PROD where possible) and revoked as soon as they are no longer needed. 

Postman is the property of Postman, Inc and its use is subject to their terms and conditions. Bloomberg does not support and is not responsible in any way for Postman usage.

## Instructions

This section explains how to setup postman to send server-mode requests to Bloomberg API Gateway.

Follow these steps - 

* Get credentials(client_id, client_secret values) from Bloomberg Developer Console.  
* Download Postman [here](https://www.getpostman.com/) 
* Copy `pre-request-script.js` into Postman Pre-request Script section.
* Now go inside postman and click on `settings icon` which is top right corner.
* Click on `Manage Environment`.
* Click on `Add`
* Add following fields inside 
    * key: `clientId` , value: `clientId from your credential`
    * key: `clientSecret`, value: `clientSecret from your credential`
* Now inside postman, add this request header -
  * key: `JWT`, value: `{{jwt}}`

Once above setup is done you can send requests to your URI using `[API host]/[endpoint path]`
eg: `GET http://api.bloomberg.com/ts/v1/documentation.json`
  
This allows testing Bloomberg API Gateway endpoints with no client side code.      
    
    
----

Copyright(C) 2019 Bloomberg Finance L.P.
All Rights Reserved.

Property of Bloomberg Finance L.P. (BLP)
This software is made available solely pursuant to the
terms of a BLP license agreement which governs its use.
