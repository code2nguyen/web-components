Sample archive for the c2n documentation: the file preview has no viewer for a ZIP, so it offers a download.
