const { post } = require('./common.js');
require('dotenv').config();

const roomId = process.env.CHAT_INIT_ROOM_ID ||"PCHAT-0x100000222222E"; // Ctrl + Shift + R on an IB room to see its ID.ex: "PCHAT-0x100000234567"
const senderUuid = parseInt(process.env.CHAT_SENDER_UUID) || 22200022; // Working sample UUID, replace with UUID of sender
const recipientOneUuid = parseInt(process.env.CHAT_RECIPIENT_ONE) || 22200022;
const recipientTwoUuid = parseInt(process.env.CHAT_RECIPIENT_TWO) || 22200022;

const payload = {
    "sender": { "uuid": senderUuid },
    "recipients": [
        { "uuid": recipientOneUuid },
        { "roomId": roomId },
        { "uuid": recipientTwoUuid }
    ],
    "chatMessage": { "text": "Hello World" },
    "table": {
        "json": {
            "rows": [
                {
                    "isHeaderRow": true,
                    "cells": [
                        {
                            "cell": [{ "text": "Ticker" }],
                            "halign": "Center"
                        },
                        {
                            "cell": [{ "text": "Company" }],
                            "halign": "Right"
                        },
                        {
                            "cell": [{ "text": "Price" }],
                            "halign": "Center"
                        }
                    ]
                },
                {
                    "cells": [
                        {
                            "cell": [
                                {
                                    "text": "ORA FP Equity",
                                    "style": {
                                        "decorations": [
                                            "Bold",
                                            "Italic",
                                        ]
                                    }
                                }
                            ]
                        },
                        {
                            "cell": [{ "text": "Orange SA" }],
                        },
                        {
                            "cell": [{ "text": "10.18" }],
                        }
                    ]
                },
                {
                    "cells": [
                        {
                            "cell": [
                                {
                                    "text": "VOD LN Equity",
                                    "style": {
                                        "decorations": [
                                            "Underline"
                                        ]
                                    }
                                }
                            ]
                        },
                        {
                            "cell": [{ "text": "Vodafone Group PLC" }],
                        },
                        {
                            "cell": [{ "text": "75.34" }],
                        }
                    ]
                },
                {
                    "cells": [
                        {
                            "cell": [
                                {
                                    "text": "OMV AV Equity",
                                    "style": {
                                        "decorations": [
                                            "Strikethrough"
                                        ]
                                    }
                                }
                            ]
                        },
                        {
                            "cell": [{ "text": "OMV AG" }],
                        },
                        {
                            "cell": [{ "text": "40.23" }],
                        }
                    ]
                },
            ]
        }
    }
};

post("/ib/v1/initiateChat", payload);