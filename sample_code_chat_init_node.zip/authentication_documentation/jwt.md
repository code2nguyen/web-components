# JWT

## What is a JWT?

JWT stands for JSON web token. A JWT is a special JSON object that is cryptographically signed and can be verified to have come from a trusted source.
The technical details are described in [RFC 7519](https://tools.ietf.org/html/rfc7519).

This is what a JWT looks like.

```txt
eyJ0eXAiOiJKV1QiLA0KICJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJqb2UiLA0KICJleHAiOjEzMDA4MTkzODAsDQogImh0dHA6Ly9leGFtcGxlLmNvbS9pc19yb290Ijp0cnVlfQ.dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjX
```

The JWT is divided into three base64url encoded portions separated by `.` (dot) characters.
Base64url encoding is like normal base64 encoding except with non-url safe characters replaced
with url safe characters (+ is replaced with -, / is replaced with _, and = is removed).

```python
import base64
base64.urlsafe_b64encode(jwt)
```

The first section is the header, the second is the payload, and the third is the signature.
The JSON objects representing the header and the payload are listed below.

header -

```javascript
{
  "alg": "HS256",
  "typ": "JWT"
}
```

payload -

```javascript
{
  "iss": "7868e7440619e0ada93dbf0b43e188b3", // client id
  "exp": 1493160501,                        // "exp" (Expiration Time) Claim - since 01/01/1970 in seconds
  "nbf": 1493160201,                        // "nbf" (Not Before) Claim - since 01/01/1970 in seconds
  "iat": 1493160201,                        // "iat" (Issued At) Claim - since 01/01/1970 in seconds
  "region": "default",                      // 'default' is the only allowed value for region
  "method": "GET",
  "path": "/feeds/equity",                         // URL path being requested
  "host": "http://bci.dev.bloomberg.com",          // host request being sent to.
  "jti": "69b2740e-d2ec-4f03-b54e-f7428fa3bd70",      // (optional) JWT ID, unique identifier for JWT
   // Below field is needed ONLY for user mode flow
  "authorization": "OAUTH Mi1UOXhpRXJKb09OVDBjYWRxT0pDbnBHV053VXpEN0Q0QVh4Wm9PY3kyZk1TZzV2NUJtTTNMWlE9PQ"
}
```

Note: Detailed description of above JWT fields can be found in https://tools.ietf.org/html/rfc7519.

The signature is computed using an HMAC SHA256 algorithm which is roughly computed as follows:

```txt
HMAC(key, sha256(header + "." + payload)).
```

Note: The actual implementation of the HMAC algorithm is more complex than described above.
See RFC 2104 for more information (though you probably shouldn't implement this yourself, find a
good existing implementation and use that instead).

## How do we use JWT?

Every WEB API request must include JWT with a valid signature. We use the same shared client secret
sent to client to validate signatures.

The process we use to validate JWTs is described in detail below.

1. The JWT is read from one and only one of the following locations.

   - jwt HTTP header.
   - jwt query string parameter.

2. JWT Signature is verified using the shared client secret.

3. JWT header & payload fields are validated as below.

```txt
- header.typ is JWT
- header.alg is one of HS256, HS384, or HS512
- payload.exp > now (the token can not be expired)
- payload.nbf >= payload.iat (the token not before time cannot be sooner than the issued at time)
- payload.nbf <= now + 5 seconds (the not before time cannot be sooner than the current time)
- payload.exp - payload.nbf <= 30(the time between the expiry and issue timestamps cannot be more than 30 seconds, tokens must be short lived)
- payload.path == request URI (the path in the token must match the path of the HTTP request)
- payload.method == request method (the method in the token must match method of the HTTP request)
- payload.host == server host (the host in the payload must match the server processing the request)
- JWT token must not be used more than once.
```

----
Copyright 2017 Bloomberg Finance L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.
