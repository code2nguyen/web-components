/**
Sample code to send an Unsolicited Idea Drawer request.

Other than the success reply you receive,
you should see corresponding action on your Bloomberg screen.
For the example given in this file you will see following text
in idea drawer:

   suggestion string 0
   suggestion string 1
   I want to buy T 3 05/15/45
*/

const { post } = require('./common.js');
require('dotenv').config();

const streamId = process.env.POST_IDEA_STREAM_ID || "91111111-9111-4111-b111-d11111111111";  // Replace with valid StreamId
const recipient = parseInt(process.env.IDEA_RECIPIENT_UUID) || 22200022; // Replace with valid UserId
const destination = process.env.POST_IDEA_ROOM_ID || "PCHAT-0x100000222222E"; // Ctrl + Shift + R on an IB room to see its ID."

function generateStructuredUnsolicitedPostRequest(
    recipient, destination, additionalSuggestions = 2
) {
    const request = {
        "@type": "UIDEA",
        "recipients": [{ 'uuid': recipient }],
        "destinations": { "roomIds": [{ "roomId": destination }] },
        "suggestions": [
            {
                "text": "I want to buy",
                "structuredTemplate":
                    [{
                        "@type": "fixed_income_cash",
                        "instrument": {
                            "bbid": "EK336104",
                            "cusip": "01748XAA",
                            "figi": "BBG008N18X67",
                            "ticker": "FCA",
                            "yellow_key": "Corp"
                        },
                        "quote": {
                            "benchmark": "BBG008N18X67",
                            "benchmark_yellow_key": "Corp",
                            "settlement_currency": "EUR",
                            "settlement_date": "September",
                            "underlying_equity": {
                                "price": 29.12,
                                "ticker": "T"
                            },
                            "values": [{
                                "ask_value": 30.11,
                                "bid_value": 30.11,
                                "value_type": "PRICE"
                            }]
                        }
                    }],
                "action": "VIEW_ONLY"
            }
        ]
    };
    for (let i = 0; i < additionalSuggestions; i++) {
        request.suggestions.push({ text: `suggestion string ${i}` });
    }
    return request;
}

const payload = generateStructuredUnsolicitedPostRequest(recipient, destination);
const postURL = `/ib/v1/streams/${streamId}`;
try {
    console.log("posting to " + postURL + "... ");
    post(postURL, payload);
} catch (e) {
    console.log("caught exception: " + e);
    console.log("URL: " + postURL);
}
